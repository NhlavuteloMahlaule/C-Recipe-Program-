﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace RecipeApp
{
    public delegate void RecipeExceedsCaloriesHandler(string recipeName);

    public class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public double Calories { get; set; }
        public string FoodGroup { get; set; }
    }

    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; } = new List<Ingredient>();
        public List<string> Steps { get; set; } = new List<string>();
        public event RecipeExceedsCaloriesHandler RecipeExceedsCalories;

        public double CalculateTotalCalories()
        {
            return Ingredients.Sum(i => i.Calories * i.Quantity);
        }

        public void AddIngredient(string name, double quantity, string unit, double calories, string foodGroup)
        {
            Ingredients.Add(new Ingredient
            {
                Name = name,
                Quantity = quantity,
                Unit = unit,
                Calories = calories,
                FoodGroup = foodGroup
            });
        }

        public void AddStep(string step)
        {
            Steps.Add(step);
        }

        public void ScaleRecipe(double factor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }
    }

    public class RecipeManager
    {
        public List<Recipe> Recipes { get; set; } = new List<Recipe>();

        public void AddRecipe(Recipe recipe)
        {
            Recipes.Add(recipe);
        }

        public void DisplayRecipes()
        {
            foreach (var recipe in Recipes.OrderBy(r => r.Name))
            {
                Console.WriteLine(recipe.Name);
            }
        }
    }

    public partial class MainWindow : Window
    {
        private RecipeManager recipeManager = new RecipeManager();
        private Recipe currentRecipe;

        public MainWindow()
        {
            InitializeComponent();
            LoadSampleData(); 
            DisplayRecipes();
        }

        private void LoadSampleData()
        {
            var recipe1 = new Recipe { Name = "Pasta" };
            recipe1.AddIngredient("Pasta", 200, "g", 300, "Carbs");
            recipe1.AddIngredient("Tomato Sauce", 150, "g", 100, "Vegetables");
            recipe1.AddStep("Boil pasta.");
            recipe1.AddStep("Mix with tomato sauce.");
            recipe1.RecipeExceedsCalories += RecipeExceedsCaloriesHandler;
            recipeManager.AddRecipe(recipe1);

            var recipe2 = new Recipe { Name = "Salad" };
            recipe2.AddIngredient("Lettuce", 100, "g", 20, "Vegetables");
            recipe2.AddIngredient("Chicken", 150, "g", 200, "Protein");
            recipe2.AddStep("Chop lettuce.");
            recipe2.AddStep("Cook chicken and mix with lettuce.");
            recipe2.RecipeExceedsCalories += RecipeExceedsCaloriesHandler;
            recipeManager.AddRecipe(recipe2);
        }

        private void RecipeExceedsCaloriesHandler(string recipeName)
        {
            MessageBox.Show($"Warning: {recipeName} exceeds 300 calories!");
        }

        private void DisplayRecipes()
        {
            foreach (var recipe in recipeManager.Recipes.OrderBy(r => r.Name))
            {
                recipeListBox.Items.Add(recipe);
            }
        }

        private void DisplayRecipe(Recipe recipe)
        {
            var recipeDetails = $"Recipe: {recipe.Name}\n";
            foreach (var ingredient in recipe.Ingredients)
            {
                recipeDetails += $"{ingredient.Name}: {ingredient.Quantity} {ingredient.Unit}\n";
            }
            recipeDetails += "Steps:\n";
            foreach (var step in recipe.Steps)
            {
                recipeDetails += $"{step}\n";
            }
            recipeDetails += $"Total Calories: {recipe.CalculateTotalCalories()}";

            recipeDetailsTextBlock.Text = recipeDetails;
        }

        private void RecipeListBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (recipeListBox.SelectedItem != null)
            {
                currentRecipe = (Recipe)recipeListBox.SelectedItem;
                DisplayRecipe(currentRecipe);
            }
        }

        private void ScaleButton_Click(object sender, RoutedEventArgs e)
        {
            if (currentRecipe != null)
            {
                double factor;
                if (double.TryParse(scaleFactorTextBox.Text, out factor))
                {
                    currentRecipe.ScaleRecipe(factor);
                    DisplayRecipe(currentRecipe);
                }
                else
                {
                    MessageBox.Show("Please enter a valid numeric scale factor.");
                }
            }
        }

        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            if (currentRecipe != null)
            {
                currentRecipe.ScaleRecipe(1); // Reset to original quantities
                DisplayRecipe(currentRecipe);
            }
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            // Clear the recipe data from the UI
          
            recipeListBox.SelectedItem = null;
            recipeDetailsTextBlock.Text = string.Empty;
        }

        private void DisplayMenuButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedRecipes = recipeListBox.SelectedItems.Cast<Recipe>().ToList();
            DisplayMenu(selectedRecipes);
        }

        private void DisplayMenu(List<Recipe> recipes)
        {
            // Display menu details, e.g., a pie chart
           
            foreach (var recipe in recipes)
            {
                Console.WriteLine($"{recipe.Name}: {recipe.CalculateTotalCalories()} calories");
            }
        }
    }
}
